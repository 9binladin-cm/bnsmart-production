import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const required = ["package.json"];
const missing = required.filter((file) => !existsSync(join(process.cwd(), file)));

if (missing.length) {
  console.error(`Project guard failed: missing ${missing.join(", ")}`);
  process.exit(1);
}

const packageJson = JSON.parse(readFileSync(join(process.cwd(), "package.json"), "utf8"));
const scripts = packageJson.scripts ?? {};
const requiredScripts = ["build", "typecheck", "check:project", "verify"];
const missingScripts = requiredScripts.filter((name) => !scripts[name]);

if (missingScripts.length) {
  console.error(`Project guard failed: missing scripts ${missingScripts.join(", ")}`);
  process.exit(1);
}

console.log("Project guard passed.");
